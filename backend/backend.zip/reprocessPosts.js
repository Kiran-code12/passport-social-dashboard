require("dotenv").config();

const supabase = require("./src/config/supabase");
const { analyzeText } = require("./src/nlp/gibberishFilter");
const { checkRelevance } = require("./src/nlp/relevanceFilter");
const { categorizeText } = require("./src/nlp/categorizer");
const { summarizeText } = require("./src/nlp/summarizer");

async function reprocessPosts() {
    console.log("Loading existing YouTube posts...");

    const { data: posts, error } = await supabase
        .from("posts")
        .select("id, original_text")
        .eq("platform", "youtube");

    if (error) {
        throw new Error(
            `Failed to load posts: ${error.message}`
        );
    }

    console.log(`Found ${posts.length} YouTube posts.`);

    let relevantCount = 0;
    let irrelevantCount = 0;
    let gibberishCount = 0;

    for (let i = 0; i < posts.length; i++) {
        const post = posts[i];
        const text = post.original_text || "";

        const analysis = analyzeText(text);
        const relevance = checkRelevance(text);

        let category = null;
        let summary = null;

        if (!analysis.isGibberish && relevance.isRelevant) {
            const categoryResult = await categorizeText(text);
            category = categoryResult.category;

            const summaryResult = await summarizeText(text);
            summary = summaryResult.summary;
        }

               await withRetry(async () => {
            const { error: updateError } = await supabase
                .from("posts")
                .update({
                    language: analysis.detectedLanguage,
                    category,
                    summary,
                    is_gibberish: analysis.isGibberish,
                    is_relevant: relevance.isRelevant
                })
                .eq("id", post.id);

            if (updateError) {
                throw new Error(
                    `Failed to update ${post.id}: ${updateError.message}`
                );
            }
        });

        if (analysis.isGibberish) {
            gibberishCount++;
        } else if (relevance.isRelevant) {
            relevantCount++;
        } else {
            irrelevantCount++;
        }

        console.log(`  Processed ${i + 1}/${posts.length}`);
    }

    console.log("");
    console.log("Reprocessing complete.");
    console.log(`Relevant: ${relevantCount}`);
    console.log(`Irrelevant: ${irrelevantCount}`);
    console.log(`Gibberish: ${gibberishCount}`);
}

reprocessPosts()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("Reprocessing failed:", error.message);
        process.exit(1);
    });
    // Network calls to Supabase can occasionally fail transiently (a brief
// connectivity blip, DNS hiccup, etc). Retrying a few times with a short
// delay handles this without treating every network wobble as fatal.
async function withRetry(fn, retries = 3, delayMs = 2000) {
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            return await fn();
        } catch (err) {
            if (attempt === retries) {
                throw err;
            }
            console.log(
                `  Retry ${attempt}/${retries - 1} after error: ${err.message}`
            );
            await new Promise((resolve) => setTimeout(resolve, delayMs));
        }
    }
}