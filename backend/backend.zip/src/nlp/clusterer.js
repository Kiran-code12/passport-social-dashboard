const crypto = require("crypto");

function tokenize(text) {
    return [...new Set(
        (text || "")
            .toLowerCase()
            .replace(/[^\p{L}\p{N}\s]/gu, " ")
            .split(/\s+/)
            .filter(word => word.length > 2)
    )];
}

function similarity(textA, textB) {
    const a = tokenize(textA);
    const b = tokenize(textB);

    if (!a.length || !b.length) return 0;

    const setB = new Set(b);
    const common = a.filter(word => setB.has(word));

    return common.length / Math.max(a.length, b.length);
}

function clusterPosts(posts, threshold = 0.25) {
    const clusters = [];

    for (const post of posts) {
        let matchedCluster = null;

        for (const cluster of clusters) {
            const representative = cluster.posts[0];

            const score = similarity(
                post.original_text,
                representative.original_text
            );

            if (score >= threshold) {
                matchedCluster = cluster;
                break;
            }
        }

        if (!matchedCluster) {
            matchedCluster = {
                cluster_id: crypto.randomUUID(),
                posts: []
            };

            clusters.push(matchedCluster);
        }

        matchedCluster.posts.push(post);
        post.cluster_id = matchedCluster.cluster_id;
    }

    return posts;
}

module.exports = {
    clusterPosts,
    similarity
};