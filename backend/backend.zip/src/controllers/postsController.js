const supabase = require("../config/supabase");
const { Parser } = require("json2csv");
const PDFDocument = require("pdfkit");

const getPosts = async (req, res) => {
    try {
        const {
            platform,
            region,
            creator,
            language,
            category,
            sentiment,
            minEngagement,
            sort = "published_at",
            order = "desc"
        } = req.query;

        let query = supabase
            .from("posts")
            .select("*");

        if (platform) {
            query = query.eq("platform", platform);
        }

        if (region) {
            query = query.eq("region", region);
        }

        if (creator) {
            query = query.or(
                `creator_name.ilike.%${creator}%,creator_handle.ilike.%${creator}%`
            );
        }

        if (language) {
            query = query.eq("language", language);
        }

        if (category) {
            query = query.eq("category", category);
        }

        if (sentiment) {
            query = query.eq("sentiment", sentiment);
        }

        const allowedSortFields = [
            "published_at",
            "created_at",
            "platform",
            "category"
        ];

        const sortField = allowedSortFields.includes(sort)
            ? sort
            : "published_at";

        const ascending = order.toLowerCase() === "asc";

        query = query.order(sortField, {
            ascending
        });

        const { data, error } = await query;

        if (error) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch posts",
                error: error.message
            });
        }

        let filteredData = data;

        // Engagement filtering is handled in JavaScript
        // because engagement is stored as JSONB.
        if (minEngagement) {
            const minimum = Number(minEngagement);

            if (!Number.isNaN(minimum)) {
                filteredData = data.filter(post => {
                    const engagement = post.engagement || {};

                    const total =
                        Number(engagement.views || 0) +
                        Number(engagement.likes || 0) +
                        Number(engagement.comments || 0);

                    return total >= minimum;
                });
            }
        }

        res.json({
            success: true,
            count: filteredData.length,
            filters: {
                platform: platform || null,
                region: region || null,
                creator: creator || null,
                language: language || null,
                category: category || null,
                sentiment: sentiment || null,
                minEngagement: minEngagement || null,
                sort: sortField,
                order: ascending ? "asc" : "desc"
            },
            data: filteredData
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Server error",
            error: error.message
        });
    }
};



const searchPosts = async (req, res) => {
    try {
        const { q } = req.query;

        if (!q || !q.trim()) {
            return res.status(400).json({
                success: false,
                message: "Search query is required"
            });
        }

        const searchTerm = q.trim();

        // translations is JSONB with dynamic language keys, so Supabase's
        // ilike can't search inside it directly. With this project's data
        // volume, fetching relevant/non-gibberish posts and matching in
        // JS across original_text, summary, and translations is simpler
        // and actually correct — the previous .or() pre-filter silently
        // excluded translation-only matches before the JS check ever ran.
        const { data, error } = await supabase
            .from("posts")
            .select("*")
            .eq("is_relevant", true)
            .eq("is_gibberish", false)
            .order("published_at", { ascending: false });

        if (error) {
            return res.status(500).json({
                success: false,
                message: "Search failed",
                error: error.message
            });
        }

       const filteredPosts = data.filter(post => {
    const originalMatch =
        (post.original_text || "")
            .toLowerCase()
            .includes(searchTerm.toLowerCase());

    const summaryMatch =
        (post.summary || "")
            .toLowerCase()
            .includes(searchTerm.toLowerCase());

    const translationMatch = Object.values(
        post.translations || {}
    ).some(translation =>
        String(translation)
            .toLowerCase()
            .includes(searchTerm.toLowerCase())
    );

    return originalMatch || summaryMatch || translationMatch;
});

res.json({
    success: true,
    query: searchTerm,
    count: filteredPosts.length,
    data: filteredPosts
});

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Server error",
            error: error.message
        });
    }
};

const exportCSV = async (req, res) => {
    try {
        const { data, error } = await supabase
            .from("posts")
            .select("*")
            .eq("is_relevant", true)
            .eq("is_gibberish", false)
            .order("published_at", { ascending: false });

        if (error) {
            return res.status(500).json({
                success: false,
                message: "Failed to fetch posts",
                error: error.message
            });
        }

        const fields = [
            "platform",
            "post_id",
            "creator_name",
            "creator_handle",
            "original_text",
            "post_url",
            "published_at",
            "language",
            "region",
            "category",
            "sentiment",
            "summary"
        ];

        const parser = new Parser({ fields });
        const csv = parser.parse(data);

        res.header("Content-Type", "text/csv");
        res.attachment("passport-posts.csv");
        res.send(csv);

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "CSV export failed",
            error: error.message
        });
    }
};
const exportPDF = async (req, res) => {
    try {
        const { data, error } = await supabase
            .from("posts")
            .select("*")
            .eq("is_relevant", true)
            .eq("is_gibberish", false)
            .order("published_at", { ascending: false });

        if (error) throw error;

        const doc = new PDFDocument({ margin: 40 });

        res.setHeader("Content-Type", "application/pdf");
        res.setHeader(
            "Content-Disposition",
            'attachment; filename="passport-posts.pdf"'
        );

        doc.pipe(res);

        doc.fontSize(20).text("Passport Social Media Posts", {
            align: "center"
        });

        doc.moveDown();

        data.forEach((post, index) => {
            doc.fontSize(12).text(`${index + 1}. ${post.platform}`);
            doc.fontSize(10).text(
                post.original_text || "No content"
            );

            if (post.category) {
                doc.text(`Category: ${post.category}`);
            }

            if (post.summary) {
                doc.text(`Summary: ${post.summary}`);
            }

            doc.moveDown();

            if (doc.y > 720) {
                doc.addPage();
            }
        });

        doc.end();

    } catch (error) {
        console.error("PDF export failed:", error);

        if (!res.headersSent) {
            res.status(500).json({
                success: false,
                message: "PDF export failed",
                error: error.message
            });
        }
    }
};
module.exports = {
    getPosts,
    searchPosts,
    exportCSV,
    exportPDF
};