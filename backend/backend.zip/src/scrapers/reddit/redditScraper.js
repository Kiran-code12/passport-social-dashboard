require("dotenv").config();

const supabase = require("../../config/supabase");

const { analyzeText } = require("../../nlp/gibberishFilter");
const { categorizeText } = require("../../nlp/categorizer");
const { checkRelevance } = require("../../nlp/relevanceFilter");
const { summarizeText } = require("../../nlp/summarizer");
const { analyzeSentiment } = require("../../nlp/sentimentAnalyzer");
const { detectRegion } = require("../../nlp/regionDetector");

const SUBREDDITS = [
    "passport",
    "immigration",
    "india",
    "travel"
];

const KEYWORD = "passport";

function getLast24Hours() {
    return Date.now() - 24 * 60 * 60 * 1000;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function withRetry(fn, retries = 3, baseDelayMs = 3000) {
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            return await fn();
        } catch (err) {
            if (attempt === retries) {
                throw err;
            }
            // Exponential backoff: 3s, 6s, 12s...
            // gives Reddit's rate-limit window more time to clear
            // instead of hammering it again after a flat delay.
            const delayMs =
                baseDelayMs * Math.pow(2, attempt - 1);

            console.log(
                `  Retry ${attempt}/${retries - 1} after error: ${err.message} (waiting ${delayMs / 1000}s)`
            );
            await sleep(delayMs);
        }
    }
}

async function fetchRedditRSS(subreddit) {
    const url =
        `https://www.reddit.com/r/${subreddit}/new.rss`;

    const response = await fetch(url, {
        headers: {
            // Reddit rate-limits/blocks generic User-Agents aggressively.
            // Their guideline format: platform:appid:version (by /u/username)
            "User-Agent":
                "nodejs:passport-social-dashboard:v1.0 (by /u/Few-Sand7706)",
            "Accept":
                "application/rss+xml, application/xml, text/xml, */*"
        }
    });

    if (!response.ok) {
        throw new Error(
            `Reddit RSS failed for r/${subreddit}: ${response.status}`
        );
    }

    return await response.text();
}

function extractEntries(xml) {
    const entries =
        xml.match(/<entry>[\s\S]*?<\/entry>/g) || [];

    return entries.map(entry => {
        const id =
            entry.match(/<id>(.*?)<\/id>/)?.[1] || "";

        const title =
            entry.match(/<title>([\s\S]*?)<\/title>/)?.[1] || "";

        const updated =
            entry.match(/<updated>(.*?)<\/updated>/)?.[1] || "";

        const author =
            entry.match(
                /<name>.*?\/u\/(.*?)<\/name>/
            )?.[1] || null;

        const link =
            entry.match(
                /<link href="(.*?)"/
            )?.[1] || null;

        const content =
            entry.match(
                /<content[^>]*>([\s\S]*?)<\/content>/
            )?.[1] || "";

        return {
            id,
            title: decodeHtml(title),
            author,
            link,
            updated,
            content: decodeHtml(content)
        };
    });
}

function decodeHtml(text) {
    return text
        .replace(/<[^>]+>/g, " ")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#39;/g, "'")
        .replace(/&quot;/g, '"')
        .replace(/\s+/g, " ")
        .trim();
}

async function normalizePost(post) {
    const originalText =
        `${post.title}\n\n${post.content}`.trim();

    if (
        !originalText
            .toLowerCase()
            .includes(KEYWORD)
    ) {
        return null;
    }

    const analysis =
        analyzeText(originalText);

    const relevance =
        checkRelevance(originalText);

    let category = null;
    let summary = null;

    if (
        !analysis.isGibberish &&
        relevance.isRelevant
    ) {
        const categoryResult =
            await categorizeText(originalText);

        category =
            categoryResult.category;

        const summaryResult =
            await summarizeText(originalText);

        summary =
            summaryResult.summary;
    }

    return {
        platform: "reddit",

        post_id: post.id,

        creator_name:
            post.author,

        creator_handle:
            post.author
                ? `u/${post.author}`
                : null,

        original_text:
            originalText,

        post_url:
            post.link,

        published_at:
            post.updated,

        language:
            analysis.detectedLanguage,

        region:
            detectRegion(originalText),

        category,

        sentiment:
            analyzeSentiment(originalText),

        engagement: {},

        summary,

        translations: {},

        is_gibberish:
            analysis.isGibberish,

        is_relevant:
            relevance.isRelevant,

        cluster_id: null,

        raw_data: post
    };
}

async function saveToSupabase(posts) {
    const validPosts =
        posts.filter(Boolean);

    if (!validPosts.length) {
        console.log(
            "No Reddit posts to save."
        );
        return;
    }

    const { data, error } =
        await supabase
            .from("posts")
            .upsert(validPosts, {
                onConflict:
                    "platform,post_id"
            })
            .select();

    if (error) {
        throw new Error(
            `Supabase upsert failed: ${error.message}`
        );
    }

    console.log(
        `Saved/updated ${data.length} Reddit posts.`
    );
}

async function runRedditScraper() {
    console.log(
        "Searching Reddit for passport posts..."
    );

    const allPosts = [];

    for (const subreddit of SUBREDDITS) {
        console.log(
            `Fetching r/${subreddit}...`
        );

        try {
            const xml = await withRetry(
                () => fetchRedditRSS(subreddit)
            );

            const entries =
                extractEntries(xml);

            for (const entry of entries) {
                const publishedTime =
                    new Date(entry.updated).getTime();

                if (
                    publishedTime >=
                    getLast24Hours()
                ) {
                    allPosts.push(entry);
                }
            }

        } catch (error) {
            console.error(
                `r/${subreddit} failed:`,
                error.message
            );

            // If we just got fully rate-limited, give Reddit
            // extra breathing room before hitting the next subreddit.
            if (error.message.includes("429")) {
                console.log(
                    "  Rate limited — pausing 8s before next subreddit..."
                );
                await sleep(8000);
            }
        }

        // Space out requests so Reddit doesn't see back-to-back
        // hits as bot traffic and rate-limit the next subreddit.
        await sleep(3000);
    }

    console.log(
        `Found ${allPosts.length} recent Reddit posts.`
    );

    const normalized = [];

    for (let i = 0; i < allPosts.length; i++) {
        const post =
            await normalizePost(
                allPosts[i]
            );

        if (post) {
            normalized.push(post);
        }

        console.log(
            `  Processed ${i + 1}/${allPosts.length}`
        );
    }

    await saveToSupabase(normalized);

    return normalized;
}

if (require.main === module) {
    runRedditScraper()
        .then(() => {
            console.log(
                "Reddit scraper completed successfully."
            );
            process.exit(0);
        })
        .catch(error => {
            console.error(
                "Reddit scraper failed:",
                error.message
            );

            process.exit(1);
        });
}

module.exports = {
    runRedditScraper
};